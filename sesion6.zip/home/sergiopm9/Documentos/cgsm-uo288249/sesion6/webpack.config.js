module.exports = {
  mode: "development",
  entry: {
    "prac6-1": "./src/prac6-1.js",
    "prac6-2": "./src/prac6-2.js",
    "prac6-3": "./src/prac6-3.js",
    "prac6-4": "./src/prac6-4.js"
  },
  output: {
    filename: "[name].js"
  },
  devServer: {
    static: {
      directory: __dirname
    },
    devMiddleware: {
      writeToDisk: true
    },
    port: 8080
  },
  performance: {
    hints: false,
    maxAssetSize: 1000000,
    maxEntrypointSize: 1000000
  },
  module: {
    rules: [
      {
        test: /\.m?js$/,
        type: "javascript/auto",
        resolve: {
          fullySpecified: false
        }
      }
    ]
  }
};
